<?php

class TFCall_Action_Widget extends \Elementor\Widget_Base {



	public function get_name() {

        return 'tf-call-to-action';

    }

    

    public function get_title() {

        return esc_html__( 'TF Call To Action', 'themesflat-core' );

    }



    public function get_icon() {

        return 'eicon-t-letter';

    }

    

    public function get_categories() {

        return [ 'themesflat_addons' ];

    }

    public function get_style_depends() {

		return ['animate-text'];

	}



	public function get_script_depends() {

		return ['animate-text'];

	}



	protected function register_controls() {

		// Start List Setting        

			$this->start_controls_section( 'section_setting',

	            [

	                'label' => esc_html__('Setting', 'themesflat-core'),

	            ]

	        );

            $this->add_control( 

	        	'style',

				[

					'label' => esc_html__( 'Style', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::SELECT,

					'default' => 'style1',

					'options' => [

						'style1' => esc_html__( 'Style 1', 'themesflat-core' ),

						'style2' => esc_html__( 'Style 2', 'themesflat-core' ),

					],

				]

			);



			$this->add_control(

				'heading',

				[

					'label' => esc_html__( 'Heading', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::TEXT,					

					'default' => esc_html__( 'Lets Start The Conversation!', 'themesflat-core' ),

					'label_block' => true,

				]

			);

			$repeater = new \Elementor\Repeater();

            $repeater->add_control(
				'animate_text',
				[
					'label' => esc_html__( 'Animate Text', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Storyteller', 'themesflat-core' ),
				]
			);

            $this->add_control(
				'list',
				[
					'label' => esc_html__( 'List', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'animate_text' => esc_html__( 'Storyteller', 'themesflat-core' ),
						],
                        [
							'animate_text' => esc_html__( 'Narrator', 'themesflat-core' ),
						],
					],
                    'condition' => [
		                'style' => 'style2',
		            ]
				]
			);


			$this->add_control(

				'description',

				[

					'label' => esc_html__( 'Description', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::TEXTAREA,					

					'default' => esc_html__( 'Have a story to share or a question to ask? Reach out were always listening and excited to hear from you!', 'themesflat-core' ),

					'label_block' => true,

					'condition' => [

						'style' => 'style1',

					],

				]

			);

            $this->add_control( 

                'button_text',

                [

                    'label' => esc_html__( 'Button Text', 'drozy' ),

                    'type' => \Elementor\Controls_Manager::TEXT,

                    'default' => esc_html__( 'Contact Us', 'drozy' ),

                ]

            );	


            $this->add_control(

				'link',

				[

					'label' => esc_html__( 'Link', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::URL,

					'placeholder' => esc_html__( 'https://your-link.com', 'themesflat-core' ),

					'default' => [

						'url' => '#',

						'is_external' => false,

						'nofollow' => false,

					],

				]

			);

	        

			$this->end_controls_section();

        // /.End List Setting  

        
			$this->start_controls_section( 'section_about_me',

	            [

	                'label' => esc_html__('Content Right', 'themesflat-core'),

                    'condition' => [
		                'style' => 'style2',
		            ]

	            ]

	        );


            $this->add_control(

				'heading_right',

				[

					'label' => esc_html__( 'Heading', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::TEXT,					

					'default' => esc_html__( 'WHAT I AM DOING', 'themesflat-core' ),

					'label_block' => true,

				]

			);


            $repeater2 = new \Elementor\Repeater();

            $repeater2->add_control(
				'content_text',
				[
					'label' => esc_html__( 'Content Text', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Content Creator', 'themesflat-core' ),
				]
			);

            $repeater2->add_control(
                'content_link',
                [
                    'label' => esc_html__( 'Link', 'themesflat-core' ),
                    'type' => \Elementor\Controls_Manager::URL,
                    'default' => [
                        'url' => '#',
                        'is_external' => false,
                        'nofollow' => false,
                    ],
                ]
            );

            $this->add_control(
				'list2',
				[
					'label' => esc_html__( 'List', 'themesflat-core' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater2->get_controls(),
					'default' => [
						[
							'content_text' => esc_html__( 'Photographer', 'themesflat-core' ),
						],
                        [
							'content_text' => esc_html__( 'Lifestyle Blogger', 'themesflat-core' ),
						],
                        [
							'content_text' => esc_html__( 'Content Creator', 'themesflat-core' ),
						],
					],
				]
			);



			$this->end_controls_section();


        // Start Style

	        $this->start_controls_section( 'section_style',

	            [

	                'label' => esc_html__( 'Style', 'themesflat-core' ),

	                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

	            ]

	        );	

			$this->add_control(

				'h_heading',

				[

					'label' => esc_html__( 'Heading', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::HEADING,

					'separator' => 'before',

				]

			);

			$this->add_group_control( 

	        	\Elementor\Group_Control_Typography::get_type(),

				[

					'name' => 'typography',

					'label' => esc_html__( 'Typography', 'themesflat-core' ),

					'selector' => '{{WRAPPER}} .heading',

				]

			); 



			$this->add_control( 

				'heading_color',

				[

					'label' => esc_html__( 'Color', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::COLOR,

					'selectors' => [

						'{{WRAPPER}} .heading' => 'color: {{VALUE}}',					

					],

				]

			);
		





		$this->add_responsive_control(

			'heading_margin',
			[
				'label'     => esc_html__( 'Spacing', 'vineta-addon' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px','%','vh' ],
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .heading' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


			$this->add_control(

				'h_description',

				[

					'label' => esc_html__( 'Description', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::HEADING,

					'separator' => 'before',

                    'condition' => [
		                'style' => 'style1',
		            ]

				]

			);



			$this->add_group_control( 

	        	\Elementor\Group_Control_Typography::get_type(),

				[

					'name' => 'typography_description',

					'label' => esc_html__( 'Typography', 'themesflat-core' ),

					'selector' => '{{WRAPPER}} .description',

                    'condition' => [
		                'style' => 'style1',
		            ]

				]

			); 



			$this->add_control( 

				'description_color',

				[

					'label' => esc_html__( 'Color', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::COLOR,

					'selectors' => [

						'{{WRAPPER}} .description' => 'color: {{VALUE}}',					

					],

                    'condition' => [
		                'style' => 'style1',
		            ]

				]

			);			





		$this->add_responsive_control(

			'description_margin',
			[
				'label'     => esc_html__( 'Spacing', 'vineta-addon' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px','%','vh' ],
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .description' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],

                  'condition' => [
		                'style' => 'style1',
		            ]
			]
		);


			$this->add_control(

				'h_button',

				[

					'label' => esc_html__( 'Button', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::HEADING,

					'separator' => 'before',

				]

			);

            $this->add_group_control( 

	        	\Elementor\Group_Control_Typography::get_type(),

				[

					'name' => 'typography_button',

					'label' => esc_html__( 'Typography', 'themesflat-core' ),

					'selector' => '{{WRAPPER}} .tf-btn',

				]

			); 



			$this->add_control( 

				'button_color',

				[

					'label' => esc_html__( 'Color', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::COLOR,

					'selectors' => [

						'{{WRAPPER}} .tf-btn' => 'color: {{VALUE}}',					

					],

				]

			);	


            $this->add_control( 

				'button_background_color',

				[

					'label' => esc_html__( 'Background', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::COLOR,

					'selectors' => [

						'{{WRAPPER}} .tf-btn' => 'background-color: {{VALUE}}',					

					],

				]

			);	
			        

            $this->add_responsive_control( 

				'button_border_radius',

				[

					'label' => esc_html__( 'Border Radius', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::DIMENSIONS,

					'size_units' => [ 'px' , '%' ],

					'selectors' => [

						'{{WRAPPER}} .tf-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

					],

				]

			);


            $this->add_control(

				'h_heading_right',

				[

					'label' => esc_html__( 'Heading Right', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::HEADING,

					'separator' => 'before',

                                        'condition' => [
		                'style' => 'style2',
		            ]

				]

			);

            $this->add_group_control( 

	        	\Elementor\Group_Control_Typography::get_type(),

				[

					'name' => 'typography_heading_right',

					'label' => esc_html__( 'Typography', 'themesflat-core' ),

					'selector' => '{{WRAPPER}} .heading-right',

                                        'condition' => [
		                'style' => 'style2',
		            ]

				]

			); 



			$this->add_control( 

				'heading_right_color',

				[

					'label' => esc_html__( 'Color', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::COLOR,

					'selectors' => [

						'{{WRAPPER}} .heading-right' => 'color: {{VALUE}}',					

					],

                                        'condition' => [
		                'style' => 'style2',
		            ]

				]

			);
		
		$this->add_responsive_control(

			'heading_right_margin',
			[
				'label'     => esc_html__( 'Spacing', 'vineta-addon' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px','%','vh' ],
				'range'     => [
					'px' => [
						'min' => 1,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .heading-right' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],

                                    'condition' => [
		                'style' => 'style2',
		            ]
			]
		);

        
            $this->add_control(

				'h_content',

				[

					'label' => esc_html__( 'Content List', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::HEADING,

					'separator' => 'before',

                                        'condition' => [
		                'style' => 'style2',
		            ]

				]

			);

            $this->add_group_control( 

	        	\Elementor\Group_Control_Typography::get_type(),

				[

					'name' => 'typography_content_right',

					'label' => esc_html__( 'Typography', 'themesflat-core' ),

					'selector' => '{{WRAPPER}} .list-work a',

                                        'condition' => [
		                'style' => 'style2',
		            ]

				]

			); 



			$this->add_control( 

				'content_right_color',

				[

					'label' => esc_html__( 'Color', 'themesflat-core' ),

					'type' => \Elementor\Controls_Manager::COLOR,

					'selectors' => [

						'{{WRAPPER}} .list-work a' => 'color: {{VALUE}}',					

					],

                    'condition' => [
		                'style' => 'style2',
		            ]

				]

			);
		

        	$this->end_controls_section();    

	    // /.End Style 


	}	



	protected function render() {

		$settings = $this->get_settings_for_display();		
        $target = $settings['link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['link']['nofollow'] ? ' rel="nofollow"' : '';
        ?>

        <?php if ($settings['style'] == 'style1'): ?>

            <!-- Section CTA -->
            <div class="section-cta text-center tf-spacing-1">
                <div class="tf-container">
                    <?php if (!empty($settings['heading'])) : ?>
                        <h1 class="mb_20 heading"><?php echo esc_html($settings['heading']); ?></h1>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['description'])) : ?>
						<?php echo sprintf( '<p class="descrition">%1$s</p>', $settings['description'] ); ?>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['link']['url']) && !empty($settings['button_text'])) : ?>
                        <a href="<?php echo esc_url($settings['link']['url']); ?>" class="tf-btn btn-switch-text animate-hover-btn mx-auto" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>>
                            <span>
                                <span class="btn-double-text" data-text="<?php echo esc_attr($settings['button_text']); ?>"><?php echo esc_html($settings['button_text']); ?></span>
                            </span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- /End Section CTA -->

        <?php else: ?>

                <!-- section-about -->
                    <div id="about" class="section-about tf-spacing-4 section">
                        <div class="tf-container">
                            <div class="row">
                                <div class="col-sm-8">
                                    <div class="heading-section mb_40">
                                        <div
                                            class="title text-display-2 fw-7 text_on-surface-color font-2 animationtext clip heading">

                                            <?php if (!empty($settings['heading'])) : ?>
													<?php echo sprintf( '%1$s', $settings['heading'] ); ?>
                                            <?php endif; ?>

                                            <span class="tf-text s1 cd-words-wrapper">
                                                <?php foreach ( $settings['list'] as $item ): ?>
                                                    <span class="item-text is-visible"><?php echo esc_html($item['animate_text']); ?></span>
                                                <?php endforeach; ?>
                                            </span>

                                        </div>
                                    </div>

                                    <?php if (!empty($settings['link']['url']) && !empty($settings['button_text'])) : ?>
                                        <a href="<?php echo esc_url($settings['link']['url']); ?>" class="tf-btn animate-hover-btn btn-switch-text" <?php echo esc_attr($target); ?> <?php echo esc_attr($nofollow); ?>>
                                            <span>
                                                <span class="btn-double-text" data-text="<?php echo esc_attr($settings['button_text']); ?>"><?php echo esc_html($settings['button_text']); ?></span>
                                            </span>
                                        </a>
                                    <?php endif; ?>

                                </div>
                                <div class="col-sm-4 text-sm-end">
                                    <?php if (!empty($settings['heading_right'])) : ?>
                                        <div class="text-title fw-7 text_on-surface-color mb_20 heading-right">
                                            <?php echo esc_html($settings['heading_right']); ?>
                                        </div>
                                    <?php endif; ?>
                                    <ul class="list-work">
                                        <?php foreach ( $settings['list2'] as $item ):?>
                                            <li class="h4"><a href="<?php echo esc_url($item['content_link']['url']) ?>" class="link"><?php echo esc_html($item['content_text']); ?></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- End section-about -->
            
        <?php endif; ?>

        <?php 		

	}



}